import os
from flask import Flask, request, render_template, redirect, url_for
import pandas as pd
import matplotlib.pyplot as plt
import openai

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Set your OpenAI API key from the environment variable
openai.api_key = os.getenv('OPENAI_API_KEY')

def read_csv(file_path):
    df = pd.read_csv(file_path)
    return df

def calculate_statistics(df):
    statistics = {
        'mean': df.mean().to_dict(),
        'median': df.median().to_dict(),
        'mode': df.mode().iloc[0].to_dict(),  # mode() returns a DataFrame
        'std_dev': df.std().to_dict(),
        'correlation': df.corr().to_dict()
    }
    return statistics

def plot_histogram(df, column):
    plt.hist(df[column], bins=30, alpha=0.7, color='blue')
    plt.title(f'Histogram of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plot_path = os.path.join(app.config['UPLOAD_FOLDER'], 'histogram.png')
    plt.savefig(plot_path)
    plt.close()
    return plot_path

def plot_scatter(df, column1, column2):
    plt.scatter(df[column1], df[column2], alpha=0.5)
    plt.title(f'Scatter plot of {column1} vs {column2}')
    plt.xlabel(column1)
    plt.ylabel(column2)
    plot_path = os.path.join(app.config['UPLOAD_FOLDER'], 'scatter.png')
    plt.savefig(plot_path)
    plt.close()
    return plot_path

def plot_line(df, column):
    plt.plot(df[column])
    plt.title(f'Line plot of {column}')
    plt.xlabel('Index')
    plt.ylabel(column)
    plot_path = os.path.join(app.config['UPLOAD_FOLDER'], 'line.png')
    plt.savefig(plot_path)
    plt.close()
    return plot_path

def ask_llm(prompt):
    response = openai.ChatCompletion.create(
        model="text-davinci-002",
        prompt=prompt,
        max_tokens=100
    )
    return response.choices[0].text.strip()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        return redirect(request.url)
    
    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        
        df = read_csv(file_path)
        stats = calculate_statistics(df)
        
        hist_path = plot_histogram(df, df.columns[0])
        scatter_path = plot_scatter(df, df.columns[0], df.columns[1])
        line_path = plot_line(df, df.columns[0])
        
        question = "What is the correlation between the first two columns?"
        prompt = f"Given the following statistics: {stats}, {question}"
        answer = ask_llm(prompt)
        
        return render_template('results.html', stats=stats, hist_path=hist_path, scatter_path=scatter_path, line_path=line_path, answer=answer)

if __name__ == '__main__':
    app.run(debug=True)
